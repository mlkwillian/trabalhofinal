package com.senai.projeto;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AlertaAdapter extends RecyclerView.Adapter<AlertaAdapter.ViewHolder> {

    private List<Alerta> listaAlertas;

    public AlertaAdapter(List<Alerta> listaAlertas) {
        this.listaAlertas = listaAlertas;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_alerta, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Alerta alerta = listaAlertas.get(position);
        holder.tvTitulo.setText(alerta.getTitulo());
        holder.tvDescricao.setText(alerta.getDescricao());
        holder.tvData.setText(alerta.getDataHora());

        // Define a cor do indicador (Vermelho para quente, Azul para frio)
        if (alerta.isQuente()) {
            holder.viewIndicador.setBackgroundColor(Color.parseColor("#FF4444"));
        } else {
            holder.viewIndicador.setBackgroundColor(Color.parseColor("#00FFFF"));
        }
    }

    @Override
    public int getItemCount() { return listaAlertas.size(); }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitulo, tvDescricao, tvData;
        View viewIndicador;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitulo = itemView.findViewById(R.id.tvAlertaTitulo);
            tvDescricao = itemView.findViewById(R.id.tvAlertaDescricao);
            tvData = itemView.findViewById(R.id.tvAlertaData);
            viewIndicador = itemView.findViewById(R.id.viewIndicadorCor);
        }
    }
}