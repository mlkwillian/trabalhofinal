package com.senai.projeto;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Referenciando os componentes
        TextView tvNome = findViewById(R.id.tvNomeDetalhe);
        TextView tvTemp = findViewById(R.id.tvTempGrande);
        TextView tvStatus = findViewById(R.id.tvStatusDetalhe);
        LinearLayout btnVoltar = findViewById(R.id.btnVoltarNovo);

        // Pegando dados da Intent
        if (getIntent() != null) {
            String nome = getIntent().getStringExtra("nome");
            String temp = getIntent().getStringExtra("temperatura");
            String status = getIntent().getStringExtra("status");

            if (nome != null) tvNome.setText(nome.toUpperCase());
            if (temp != null) tvTemp.setText(temp);
            if (status != null) tvStatus.setText("Status:    " + status.toUpperCase());
        }

        // Ação de fechar a tela
        if (btnVoltar != null) {
            btnVoltar.setOnClickListener(v -> finish());
        }
    }
}