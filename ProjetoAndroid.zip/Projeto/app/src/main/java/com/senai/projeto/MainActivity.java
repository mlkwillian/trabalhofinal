package com.senai.projeto;

import android.os.Bundle;
import android.view.MenuItem; // ESTE IMPORT ESTAVA FALTANDO!
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView nav = findViewById(R.id.bottom_navigation);

        // Carrega o Dashboard por padrão ao abrir
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new DashboardFragment())
                    .commit();
        }

        nav.setOnItemSelectedListener(item -> {
            Fragment selecionado = null;
            int id = item.getItemId();

            if (id == R.id.nav_dashboard) {
                selecionado = new DashboardFragment();
            } else if (id == R.id.nav_perfil) {
                selecionado = new PerfilFragment();
            } else if (id == R.id.nav_config) {
                selecionado = new ConfigFragment();
            }

            if (selecionado != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, selecionado)
                        .commit();
            }
            return true;
        });
    }
}