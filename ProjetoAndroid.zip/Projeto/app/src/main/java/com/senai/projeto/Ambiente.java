package com.senai.projeto;

public class Ambiente {
    public String nome;
    public String temperatura;
    public String status;
    public int progresso;

    // ESSE BLOCO ABAIXO É O CONSTRUTOR (O que está faltando!)
    public Ambiente(String nome, String temperatura, String status, int progresso) {
        this.nome = nome;
        this.temperatura = temperatura;
        this.status = status;
        this.progresso = progresso;
    }
}