package com.senai.projeto;

import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class AmbienteAdapter extends RecyclerView.Adapter<AmbienteAdapter.ViewHolder> {

    private List<Ambiente> lista;

    public AmbienteAdapter(List<Ambiente> lista) {
        this.lista = lista;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_ambiente, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Ambiente a = lista.get(position);

        // Preenchimento dos dados
        holder.nome.setText(a.nome);
        holder.temp.setText(a.temperatura);
        holder.status.setText(a.status);
        holder.barra.setProgress(a.progresso);

        // Lógica de cores original (Bordas e Textos)
        if (a.status.contains("Normal")) {
            holder.layoutPrincipal.setBackgroundResource(R.drawable.bg_card_normal);
            holder.temp.setTextColor(Color.WHITE);
        } else if (a.status.contains("Acima")) {
            holder.layoutPrincipal.setBackgroundResource(R.drawable.bg_card_alerta);
            holder.temp.setTextColor(Color.parseColor("#FF4B4B"));
        } else if (a.status.contains("Atenção")) {
            holder.layoutPrincipal.setBackgroundResource(R.drawable.bg_card_atencao);
            holder.temp.setTextColor(Color.parseColor("#FFD700"));
        }

        // --- LÓGICA DE CLIQUE PARA DETALHES ---
        holder.itemView.setOnClickListener(v -> {
            // Cria a Intent para abrir a DetailActivity
            Intent intent = new Intent(v.getContext(), DetailActivity.class);

            // Passa os dados do objeto 'Ambiente' clicado para a próxima tela
            intent.putExtra("nome", a.nome);
            intent.putExtra("temperatura", a.temperatura);
            intent.putExtra("status", a.status);

            // Inicia a DetailActivity usando o contexto da View
            v.getContext().startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        android.util.Log.d("ADAPTER", "Itens = " + lista.size());
        return lista.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nome, temp, status;
        ProgressBar barra;
        LinearLayout layoutPrincipal;

        public ViewHolder(@NonNull View v) {
            super(v);
            nome = v.findViewById(R.id.tvNomeItem);
            temp = v.findViewById(R.id.tvTempItem);
            status = v.findViewById(R.id.tvStatus);
            barra = v.findViewById(R.id.pbTemp);
            layoutPrincipal = v.findViewById(R.id.layoutItemPrincipal);
        }
    }
}