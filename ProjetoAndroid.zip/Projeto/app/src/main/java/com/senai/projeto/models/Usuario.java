package com.senai.projeto.models;


public class Usuario {

    private int id;
    private String nome;
    private String email;
    private String senha;
    private String token;

    private String tipo_usuario;


    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public String getSenha() {
        return senha;
    }

    public String getToken() {
        return token;
    }

    public String getTipo_usuario() {
        return tipo_usuario;
    }
}
