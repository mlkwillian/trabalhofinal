package com.senai.projeto;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.senai.projeto.api.ApiService;
import com.senai.projeto.api.RetrofitClient;
import com.senai.projeto.models.Usuario;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PerfilFragment extends Fragment {

    private TextView txtNome;
    private TextView txtEmail;
    private TextView txtCargo;
    private TextView txtInicial;

    @Override
    public View onCreateView(
            LayoutInflater inflater,
            ViewGroup container,
            Bundle savedInstanceState) {

        View view = inflater.inflate(
                R.layout.activity_perfil,
                container,
                false
        );

        txtNome = view.findViewById(R.id.txtNome);
        txtEmail = view.findViewById(R.id.txtEmail);
        txtCargo = view.findViewById(R.id.txtCargo);
        txtInicial = view.findViewById(R.id.txtInicial);

        carregarPerfil();

        return view;
    }

    private void carregarPerfil() {

        SharedPreferences prefs =
                requireActivity().getSharedPreferences(
                        "APP",
                        Context.MODE_PRIVATE
                );

        String token =
                prefs.getString("TOKEN", "");

        ApiService api =
                RetrofitClient
                        .getRetrofit()
                        .create(ApiService.class);

        api.getPerfil("Bearer " + token)
                .enqueue(new Callback<Usuario>() {

                    @Override
                    public void onResponse(
                            Call<Usuario> call,
                            Response<Usuario> response) {

                        Log.d("PERFIL", "Código: " + response.code());

                        if(response.isSuccessful()) {

                            Usuario usuario =
                                    response.body();

                            txtNome.setText(
                                    usuario.getNome()
                            );

                            txtEmail.setText(
                                    usuario.getEmail()
                            );

                            txtCargo.setText(
                                    usuario.getTipo_usuario()
                            );

                            String[] nomes =
                                    usuario.getNome().split(" ");

                            String iniciais =
                                    nomes[0].substring(0,1);

                            if(nomes.length > 1){
                                iniciais +=
                                        nomes[nomes.length - 1]
                                                .substring(0,1);
                            }

                            txtInicial.setText(
                                    iniciais.toUpperCase()
                            );
                        } else {

                        Log.d("PERFIL", "Erro: " + response.code());

                    }
                    }

                    @Override
                    public void onFailure(
                            Call<Usuario> call,
                            Throwable t) {

                        Log.e("PERFIL", t.getMessage());

                        t.printStackTrace();
                    }
                });
    }
}