package com.senai.projeto;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

public class ConfigFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Infla o layout correspondente às configurações
        return inflater.inflate(R.layout.activity_config, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // 1. Vincula o CardView de desconectar usando o ID do seu XML
        CardView btnSair = view.findViewById(R.id.btnSair);

        // 2. Configura a ação de clique para deslogar
        if (btnSair != null) {
            btnSair.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Cria a rota para voltar para a tela de Login
                    Intent intent = new Intent(getActivity(), LoginActivity.class);

                    // Limpa o histórico de telas para o usuário não conseguir voltar ao app pelo botão físico do celular
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

                    // Inicia a LoginActivity
                    startActivity(intent);

                    // Finaliza a Activity principal que abrigava este Fragment
                    if (getActivity() != null) {
                        getActivity().finish();
                    }
                }
            });
        }
    }
}