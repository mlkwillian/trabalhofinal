package com.senai.projeto.api;

import com.senai.projeto.models.Sala;
import com.senai.projeto.models.Usuario;
import com.senai.projeto.requests.LoginRequest;
import com.senai.projeto.requests.SalaRequest;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface ApiService {

    @POST("login")
    Call<Usuario> login(@Body LoginRequest request);

    @GET("salas")
    Call<List<Sala>> listarSalas(
            @Header("Authorization") String token
    );

    @POST("salas")
    Call<Sala> criarSala(
            @Header("Authorization") String token,
            @Body SalaRequest request
    );

    @GET("me")
    Call<Usuario> getPerfil(
            @Header("Authorization") String token
    );
}