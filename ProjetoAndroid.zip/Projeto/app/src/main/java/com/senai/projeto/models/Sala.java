package com.senai.projeto.models;

import com.google.gson.annotations.SerializedName;

public class Sala {

    @SerializedName("id_sala")
    private int id;

    @SerializedName("nome_sala")
    private String nome;

    @SerializedName("temperatura")
    private Double temperatura;

    @SerializedName("umidade")
    private double umidade;

    @SerializedName("temperatura_min")
    private double temperaturaMin;

    @SerializedName("temperatura_max")
    private double temperaturaMax;

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public Double getTemperatura() {
        return temperatura;
    }

    public double getUmidade() {
        return umidade;
    }

    public double getTemperaturaMin() {
        return temperaturaMin;
    }

    public double getTemperaturaMax() {
        return temperaturaMax;
    }
}