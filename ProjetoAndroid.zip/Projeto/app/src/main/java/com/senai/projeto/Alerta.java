package com.senai.projeto;

public class Alerta {
    private String titulo;
    private String descricao;
    private String dataHora;
    private boolean isQuente; // true = vermelho, false = azul

    public Alerta(String titulo, String descricao, String dataHora, boolean isQuente) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataHora = dataHora;
        this.isQuente = isQuente;
    }

    // Getters
    public String getTitulo() { return titulo; }
    public String getDescricao() { return descricao; }
    public String getDataHora() { return dataHora; }
    public boolean isQuente() { return isQuente; }
}