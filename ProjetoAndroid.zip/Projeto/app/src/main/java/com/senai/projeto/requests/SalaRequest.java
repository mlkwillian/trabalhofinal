package com.senai.projeto.requests;

import com.google.gson.annotations.SerializedName;

public class SalaRequest {

    @SerializedName("nome_sala")
    private String nome;

    @SerializedName("temperatura_min")
    private double tempMin;

    @SerializedName("temperatura_max")
    private double tempMax;

    public SalaRequest(String nome, double tempMin, double tempMax) {
        this.nome = nome;
        this.tempMin = tempMin;
        this.tempMax = tempMax;
    }

    public String getNome() {
        return nome;
    }

    public double getTempMin() {
        return tempMin;
    }

    public double getTempMax() {
        return tempMax;
    }
}