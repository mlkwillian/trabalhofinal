package com.senai.projeto;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.senai.projeto.api.ApiService;
import com.senai.projeto.api.RetrofitClient;
import com.senai.projeto.models.Sala;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardFragment extends Fragment {

    private RecyclerView rvAmbientes;
    private AmbienteAdapter adapter;
    private List<Ambiente> listaAmbientes = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Infla o layout que você enviou (activity_dashboard.xml)
        return inflater.inflate(R.layout.activity_dashboard, container, false);
    }

    private void carregarSalas() {

        String token = requireActivity()
                .getSharedPreferences("APP", getContext().MODE_PRIVATE)
                .getString("TOKEN", "");

        ApiService apiService = RetrofitClient
                .getRetrofit()
                .create(ApiService.class);

        apiService.listarSalas("Bearer " + token)
                .enqueue(new Callback<List<Sala>>() {

                    @Override
                    public void onResponse(Call<List<Sala>> call,
                                           Response<List<Sala>> response) {

                        if (response.isSuccessful() && response.body() != null) {

                            android.util.Log.d("SALAS", "Total: " + response.body().size());

                            listaAmbientes.clear();

                            for (Sala sala : response.body()) {

                                android.util.Log.d("SALAS", sala.getNome());

                                String temperatura = sala.getTemperatura() == null
                                        ? "--°C"
                                        : sala.getTemperatura() + "°C";

                                String status = sala.getTemperatura() != null
                                        ? "● Online"
                                        : "● Offline";

                                listaAmbientes.add(
                                        new Ambiente(
                                                sala.getNome(),
                                                temperatura,
                                                status,
                                                50
                                        )
                                );
                            }

                            adapter.notifyDataSetChanged();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Sala>> call, Throwable t) {

                        Toast.makeText(getContext(),
                                t.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Botão histórico
        ImageButton btnSino = view.findViewById(R.id.btnAbrirLog);

        btnSino.setOnClickListener(v -> {

            Intent intent = new Intent(getContext(), HistoricoActivity.class);
            startActivity(intent);
        });

        // Botão adicionar
        FloatingActionButton fabAdd = view.findViewById(R.id.fabAdd);

        fabAdd.setOnClickListener(v -> {

            Intent intent = new Intent(getContext(), CadastroActivity.class);
            startActivity(intent);
        });

        // RecyclerView
        rvAmbientes = view.findViewById(R.id.rvAmbientes);

        rvAmbientes.setLayoutManager(
                new LinearLayoutManager(getContext())
        );

        // CRIA O ADAPTER PRIMEIRO
        adapter = new AmbienteAdapter(listaAmbientes);

        rvAmbientes.setAdapter(adapter);

        ImageButton btnRefresh = view.findViewById(R.id.btnRefresh);

        btnRefresh.setOnClickListener(v -> {

            btnRefresh.animate()
                    .rotationBy(360)
                    .setDuration(600)
                    .start();

            carregarSalas();

            Toast.makeText(
                    getContext(),
                    "Atualizando ambientes...",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // DEPOIS CARREGA
        carregarSalas();
    }

    @Override
    public void onResume() {
        super.onResume();

        carregarSalas();
    }
}