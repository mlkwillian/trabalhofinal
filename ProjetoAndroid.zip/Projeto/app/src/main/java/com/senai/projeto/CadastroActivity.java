package com.senai.projeto;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.senai.projeto.api.ApiService;
import com.senai.projeto.api.RetrofitClient;
import com.senai.projeto.models.Sala;
import com.senai.projeto.requests.SalaRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.widget.ImageButton;

public class CadastroActivity extends AppCompatActivity {

    private EditText etNome;
    private EditText etTempMin;
    private EditText etTempMax;
    private Button btnSalvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        etNome = findViewById(R.id.etNomeAmbiente);
        etTempMin = findViewById(R.id.etTempMin);
        etTempMax = findViewById(R.id.etTempMax);
        btnSalvar = findViewById(R.id.btnSalvar);
        ImageButton btnVoltar = findViewById(R.id.btnVoltar);

        btnVoltar.setOnClickListener(v -> {
            finish();
            overridePendingTransition(
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
            );
        });
        btnSalvar.setOnClickListener(v -> cadastrarSala());

    }

    private void cadastrarSala() {

        String nome = etNome.getText().toString().trim();
        String min = etTempMin.getText().toString().trim();
        String max = etTempMax.getText().toString().trim();

        if (nome.isEmpty()) {
            etNome.setError("Digite o nome");
            return;
        }

        if (min.isEmpty()) {
            etTempMin.setError("Digite a temperatura mínima");
            return;
        }

        if (max.isEmpty()) {
            etTempMax.setError("Digite a temperatura máxima");
            return;
        }

        int temperaturaMinima = Integer.parseInt(min);
        int temperaturaMaxima = Integer.parseInt(max);

        String token = getSharedPreferences("APP", MODE_PRIVATE)
                .getString("TOKEN", "");

        ApiService apiService = RetrofitClient
                .getRetrofit()
                .create(ApiService.class);

        SalaRequest request = new SalaRequest(
                nome,
                temperaturaMinima,
                temperaturaMaxima
        );

        apiService.criarSala("Bearer " + token, request)
                .enqueue(new Callback<Sala>() {

                    @Override
                    public void onResponse(Call<Sala> call, Response<Sala> response) {

                        if (response.isSuccessful()) {

                            Toast.makeText(
                                    CadastroActivity.this,
                                    "Sala cadastrada!",
                                    Toast.LENGTH_SHORT
                            ).show();

                            finish();

                        } else {

                            try {

                                String erro = response.errorBody().string();

                                Toast.makeText(
                                        CadastroActivity.this,
                                        erro,
                                        Toast.LENGTH_LONG
                                ).show();

                            } catch (Exception e) {

                                Toast.makeText(
                                        CadastroActivity.this,
                                        "Erro ao cadastrar",
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                    }

                    @Override
                    public void onFailure(Call<Sala> call, Throwable t) {

                        Toast.makeText(
                                CadastroActivity.this,
                                t.getMessage(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                });
    }
}