package com.senai.projeto;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.senai.projeto.api.ApiService;
import com.senai.projeto.api.RetrofitClient;
import com.senai.projeto.models.Usuario;
import com.senai.projeto.requests.LoginRequest;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {

    private EditText etEmail, etSenha;
    private Button btnLogin;
    private TextView tvEsqueci;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Vincular componentes
        etEmail = findViewById(R.id.etEmail);
        etSenha = findViewById(R.id.etSenha);
        btnLogin = findViewById(R.id.btnLogin);
        tvEsqueci = findViewById(R.id.tvEsqueci);

        // Clique login
        btnLogin.setOnClickListener(v -> fazerLogin());

        // Esqueci senha
        if (tvEsqueci != null) {
            tvEsqueci.setOnClickListener(v -> abrirDialogEsqueciSenha());
        }
    }

    private void fazerLogin() {

        String email = etEmail.getText().toString().trim();
        String senha = etSenha.getText().toString().trim();

        if (email.isEmpty()) {
            etEmail.setError("Digite o e-mail");
            return;
        }

        if (senha.isEmpty()) {
            etSenha.setError("Digite a senha");
            return;
        }

        ApiService apiService = RetrofitClient
                .getRetrofit()
                .create(ApiService.class);

        LoginRequest request = new LoginRequest(email, senha);

        apiService.login(request).enqueue(new Callback<Usuario>() {

            @Override
            public void onResponse(Call<Usuario> call, Response<Usuario> response) {

                if (response.isSuccessful() && response.body() != null) {

                    Usuario usuario = response.body();

                    String token = usuario.getToken();

                    getSharedPreferences("APP", MODE_PRIVATE)
                            .edit()
                            .putString("TOKEN", token)
                            .apply();

                    Toast.makeText(LoginActivity.this,
                            "Login realizado!",
                            Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();

                } else {

                    Toast.makeText(LoginActivity.this,
                            "Email ou senha inválidos",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Usuario> call, Throwable t) {

                Toast.makeText(LoginActivity.this,
                        "Erro: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    // Dialog recuperar senha
    private void abrirDialogEsqueciSenha() {

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_esqueci_senha, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();

        EditText etEmailRecuperacao =
                dialogView.findViewById(R.id.etEmailRecuperacao);

        Button btnCancelar =
                dialogView.findViewById(R.id.btnCancelarRecuperar);

        Button btnEnviar =
                dialogView.findViewById(R.id.btnEnviarRecuperar);

        if (btnCancelar != null) {
            btnCancelar.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnEnviar != null) {

            btnEnviar.setOnClickListener(v -> {

                String emailRecuperar =
                        etEmailRecuperacao.getText().toString().trim();

                if (emailRecuperar.isEmpty()) {

                    etEmailRecuperacao.setError("Digite seu e-mail");

                } else {

                    Toast.makeText(
                            LoginActivity.this,
                            "E-mail enviado para: " + emailRecuperar,
                            Toast.LENGTH_LONG
                    ).show();

                    dialog.dismiss();
                }
            });
        }

        dialog.show();
    }
}