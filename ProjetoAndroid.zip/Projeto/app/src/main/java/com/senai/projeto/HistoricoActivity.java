package com.senai.projeto;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class HistoricoActivity extends AppCompatActivity {

    private List<Alerta> listaAlertas = new ArrayList<>();
    private AlertaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico);

        // CONFIGURAR O CLIQUE PARA VOLTAR
        // Buscamos o Card porque ele tem a área de toque maior
        CardView cardVoltar = findViewById(R.id.cardVoltar);
        if (cardVoltar != null) {
            cardVoltar.setOnClickListener(v -> {
                finish(); // Isso fecha a tela e volta para o Dashboard
            });
        }

        // BOTAO LIMPAR
        TextView tvLimpar = findViewById(R.id.tvLimparHistorico);
        if (tvLimpar != null) {
            tvLimpar.setOnClickListener(v -> {
                listaAlertas.clear();
                adapter.notifyDataSetChanged();
            });
        }

        // RECYCLERVIEW
        RecyclerView rv = findViewById(R.id.rvHistorico);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);
        rv.setLayoutManager(layoutManager);

        // DADOS DE TESTE
        if (listaAlertas.isEmpty()) {
            listaAlertas.add(new Alerta("SALA DE PRODUÇÃO", "Atingiu 32°C (Limite: 26°C)", "28 Abr - 10:45", true));
            listaAlertas.add(new Alerta("CÂMARA FRIA", "Atingiu 2°C (Limite: -5°C)", "28 Abr - 09:12", false));
        }

        adapter = new AlertaAdapter(listaAlertas);
        rv.setAdapter(adapter);
    }
}