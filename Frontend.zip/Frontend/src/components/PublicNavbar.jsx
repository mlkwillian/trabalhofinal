"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { Sun, Moon } from "lucide-react";

export default function PublicNavbar() {
  const [dark, setDark] = useState(true);

  useEffect(() => {
    const saved = localStorage.getItem("theme");
    if (saved) setDark(saved === "dark");
  }, []);

  useEffect(() => {
    localStorage.setItem("theme", dark ? "dark" : "light");

    if (dark) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [dark]);

  return (
    <header className="w-full h-16 flex items-center justify-between px-6 border-b border-purple-900/20 bg-[#0b0a14]">
      
      {/* Logo */}
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 to-purple-400" />
        <h1 className="text-white font-bold text-lg">ThermoGuard</h1>
      </div>

      

      {/* Ações */}
      <div className="flex items-center gap-3">
        
        

        {/* Login */}
        <Link
          href="/login"
          className="px-4 py-2 rounded-lg text-sm text-purple-300 hover:text-white transition"
        >
          Entrar
        </Link>

        {/* CTA */}
        <Link
          href="login/criar"
          className="px-4 py-2 rounded-lg bg-purple-600 hover:bg-purple-700 transition text-white text-sm font-medium"
        >
          Criar conta
        </Link>
      </div>
    </header>
  );
}